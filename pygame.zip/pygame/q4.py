# Concept based off MMORPG Oldschool Runescape, where fighting NPCs is one of many things done during gameplay.
# All images taken from www.oldschoolrunescape.wikia.com

from tkinter import *
import tkinter.messagebox
import random

class DragonSlayer(Frame):
    playersHealth =0                        #starting health of player
    playersStrength=random.randint(60,99)   #starting strength of player
    wepStrength=0                           #reains 0 until weapon selected
    monstStrength=0                         #remains 0 until opponent selected
    monstHealth=1000                        #remains 0 until opponent selected
    totalFood=random.randint(5,10)          #starting food amount for player
    monstCount=0                            #tally of opponents defeated
    bonusFood=0                             #remains 0 until opponent defeated, then random between 0-3

    def weapons(self, weapon):              #stats for each weapon
        if weapon == "Abyssal Whip":
            self.weaponStrength.configure(text = 70)
            self.wepStrength=70
            self.showWhip()
        elif weapon =="Dragon Scimitar":
            self.weaponStrength.configure(text = 60)
            self.wepStrength=60
            self.showScim()
        elif weapon == "Bronze Dagger":
            self.weaponStrength.configure(text = 10)
            self.wepStrength=10
            self.showDag()
        elif weapon=="Rune Sword":
            self.weaponStrength.configure(text = 40)
            self.wepStrength=40
            self.showSword()

    def monsters(self, monster):            #stats for each opponent
        if monster == "Abyssal Demon":
            self.monstStrength=random.randint(80, 120)
            self.monstHealth=random.randint(80, 120)
            self.monsterHealth.configure(text=self.monstHealth)
            self.monsterStrength.configure(text=self.monstStrength)
            self.showDemon()

        elif monster == "Gargoyle":
            self.monstStrength=random.randint(35, 65)
            self.monstHealth=random.randint(80, 110)
            self.monsterHealth.configure(text=self.monstHealth)
            self.monsterStrength.configure(text=self.monstStrength)
            self.showGargoyle()

        elif monster == "Greater Demon":
            self.monstStrength=random.randint(50, 80)
            self.monstHealth=random.randint(40, 80)
            self.monsterHealth.configure(text=self.monstHealth)
            self.monsterStrength.configure(text=self.monstStrength)
            self.showGDemon()

        elif monster == "Hill Giant":
            self.monstStrength=random.randint(50,75)
            self.monstHealth=random.randint(60, 85)
            self.monsterHealth.configure(text=self.monstHealth)
            self.monsterStrength.configure(text=self.monstStrength)
            self.showGiant()

    def startingStats(self):        #stats for the user
        if self.playersHealth !=0:  #prevents user from spawning stats in the middle of a fight
            tkinter.messagebox.showinfo("Spawn Error","Please finish your current round before trying to spawn a player.")

        else:
            self.playersHealth =random.randint(40,65)
            self.playerHealth.configure(text= self.playersHealth)
            self.playerStrength.configure(text=self.playersStrength)
            self.playerFood.configure(text=self.totalFood)
            self.weapons(self)
            self.monsters(self)

    def fight(self):
        if self.playersHealth==0:       #prevents starting fight without a character spawned
            tkinter.messagebox.showinfo("Player load error","Please spawn your character before starting battle")
        elif self.monstHealth==1000:    #prevents starting fight without selecting opponent
            tkinter.messagebox.showinfo("Monster error","Please choose an opponent to battle.")
            if self.playersHealth <= 0: #player death notification
                tkinter.messagebox.showinfo("Player Death","Oh dear, you have died! Better luck next time.")
        elif self.monstHealth<0:        #prevents fight from continuing after opponent has been defeated
            tkinter.messagebox.showinfo("Monster error","Please choose an opponent to battle.")
        else:
            self.playerMaxHit=(self.playersStrength+self.wepStrength)/10
            self.monstMaxHit=self.monstStrength/10
            self.playersCurrentHit=random.randint(0,int(self.playerMaxHit))
            self.monstersCurrentHit=random.randint(0,int(self.monstMaxHit))
            self.playersHealth -= self.monstersCurrentHit
            self.playerHealth.configure(text=self.playersHealth)
            self.monstHealth-=self.playersCurrentHit
            self.monsterHealth.configure(text=self.monstHealth)
            self.playerDamage.configure(text=self.monstersCurrentHit)
            self.opponentDamage.configure(text=self.playersCurrentHit)
            self.playerDamageLabel.configure(text="Damage to player")   #shows damage done by opponent
            self.oppDamageLabel.configure(text="Damage to opponent")    #shows damage done by player
            if self.playersHealth <= 0: #notification of player death and how many opponents defeated
                self.playersHealth =0
                self.playerHealth.configure(text=(self.playersHealth))
                tkinter.messagebox.showinfo("Player Death",("Oh dear, you have died after defeating ", self.monstCount, " opponents! Better luck next time."))
            elif self.monstHealth<= 0:      #notification of opponent defeat and a chance of gaining extra food
                self.bonusFood=random.randint(0,3)
                tkinter.messagebox.showinfo("Opponent Defeated",("You defeated your opponent and are provided with ", self.bonusFood," extra food. Please choose another opponent."))
                self.monstCount+=1
                self.totalFood+=self.bonusFood
                self.playerFood.configure(text=self.totalFood)
                self.playerHealth.configure(text=self.playersHealth)

    def eatFood(self):
        if self.totalFood==0:       #prevents player eating food when <=0
            tkinter.messagebox.showinfo("Food error","Oh dear, you have no food left and are unable to heal!")
        else:
            self.playersHealth+=10      #each food heals 10 hitpoints
            self.totalFood-=1
            self.playerHealth.configure(text=self.playersHealth)
            self.playerFood.configure(text=self.totalFood)

    def aboutGame(self):
        tkinter.messagebox.showinfo("About Game",("The aim of this game is to defeat as many opponents as you can without perishing."\
        " all opponents have different health levels and different strength levels. The higher their strength, the higher their maximum hit. \n\nClicking \"Spawn Fighter\" "\
        "allows you to spawn a random strength level, random health level, and random amount of food for your character. Each food you eat heals your character 10 health. The higher your strength level"\
        "the higher the maximum hit your character is capable of.\n\nYou can also select a weapon,with each weapon having it's own unique strength level that effects your characters maximum hit.\n\n Good luck!"))

    def showDemon(self):

        self.photo = PhotoImage(file="AbyssalDemon.png")
        self.label = Label(self.MonsterFrame, image=self.photo)
        self.label.grid(column= 0,row=5, sticky=E)

    def showGargoyle(self):

        self.photo = PhotoImage(file="Gargoyle.png")
        self.label = Label(self.MonsterFrame, image=self.photo)
        self.label.grid(column= 0,row=5, sticky=E)

    def showGiant(self):

        self.photo = PhotoImage(file="HillGiant.png")
        self.label = Label(self.MonsterFrame, image=self.photo)
        self.label.grid(column= 0,row=5, sticky=E)

    def showGDemon(self):

        self.photo = PhotoImage(file="GreaterDemon.png")
        self.label = Label(self.MonsterFrame, image=self.photo)
        self.label.grid(column= 0, row=5, sticky=E)

    def showWhip(self):

        self.wep = PhotoImage(file="AbyssalWhip.png")
        self.label = Label(self.PlayerFrame, image=self.wep)
        self.label.grid(column= 1,row=9)

    def showScim(self):

        self.wep = PhotoImage(file="DragonScimitar.png")
        self.label = Label(self.PlayerFrame, image=self.wep)
        self.label.grid(column= 1,row=9)

    def showDag(self):

        self.wep = PhotoImage(file="BronzeDagger.png")
        self.label = Label(self.PlayerFrame, image=self.wep)
        self.label.grid(column= 1,row=9)

    def showSword(self):

        self.wep = PhotoImage(file="RuneSword.png")
        self.label = Label(self.PlayerFrame, image=self.wep)
        self.label.grid(column= 1,row=9)

    def __init__(self):     #initializing program
        Frame.__init__(self)        #main frame
        self.master.title("Ultimate Fighting Tournament")
        self.PlayerFrame=Frame(self.master, bd=3, relief=RAISED)        #sub frame holds the player information
        self.MonsterFrame=Frame(self.master, bd=3, relief=RAISED)       #sub frame holds monster information
        self.MonsterFrame.grid(row=2, column=2, padx= 10, pady=10, sticky=N)
        self.PlayerFrame.grid(row=2, column=0, padx= 10, pady=10, sticky=N)
        self.TitleFrame=Frame(self.master)      #subframe holds the title
        self.TitleFrame.grid(row=0, column=1, padx= 10, pady=10)
        self.FightFrame=Frame(self.master, bd=3, relief=RAISED)         #subframe holds fight information
        self.FightFrame.grid(column=1, row=2)
        self.grid()

        self.menu = Menu(self.master)       #menu with submenus
        self.master.config(menu=self.menu)
        self.aboutSubMenu = Menu(self.menu)
        self.menu.add_cascade(label="File", menu=self.aboutSubMenu)
        self.aboutSubMenu.add_command(label="About", command=self.aboutGame)
        self.opponents = Menu(self.menu)
        self.menu.add_cascade(label="Opponents", menu=self.opponents)
        self.opponents.add_command(label="Abyssal Demon", command=self.showDemon)
        self.opponents.add_command(label="Gargoyle", command=self.showGargoyle)
        self.opponents.add_command(label="Giant", command=self.showGiant)
        self.opponents.add_command(label="Greater Demon", command=self.showGDemon)
        self.weapons1= Menu(self.menu)
        self.menu.add_cascade(label="Weapons", menu=self.weapons1)
        self.weapons1.add_command(label="Abyssal Whip", command=self.showWhip)
        self.weapons1.add_command(label="Dragon Scimitar", command=self.showScim)
        self.weapons1.add_command(label="Bronze Dagger", command=self.showDag)
        self.weapons1.add_command(label="Rune Sword", command=self.showSword)

        self.heal=IntVar()
        self.monster = IntVar(self.MonsterFrame)
        self.weapon = IntVar(self.PlayerFrame)

        ### WIDGETS TO GO IN PLAYERFRAME ###
        self.welcome = Label(self.TitleFrame, text="Welcome to the Ultimate Fighting Tournament!", font=("",15), fg="red", bg="black")
        self.welcome.grid(row=0, column=3, sticky=E)

        self.spawnStats = Button(self.PlayerFrame, text="Spawn fighter details", command = self.startingStats)
        self.spawnStats.grid(row=2,column = 1, padx=2, pady=2)

        self.playerHealthLabel = Label(self.PlayerFrame, text="Player health:" )
        self.playerHealthLabel.grid(sticky = E,row=3, column=1)

        self.playerHealth = Label(self.PlayerFrame, text="0" )
        self.playerHealth.grid(sticky=W, row=3, column=2)

        self.playerStrengthLabel = Label(self.PlayerFrame, text="Player strength level:")
        self.playerStrengthLabel.grid(sticky =E, row=4, column=1)

        self.playerStrength = Label(self.PlayerFrame, text="0")
        self.playerStrength.grid(sticky=W, row=4, column=2)

        self.weapon.set("Choose your weapon")

        self.weaponsMenu = OptionMenu(self.PlayerFrame, self.weapon, "Abyssal Whip", "Dragon Scimitar", "Bronze Dagger","Rune Sword", command = self.weapons)
        self.weaponsMenu.grid(row=8, column = 1)

        self.weaponStrength = Label(self.PlayerFrame, text="0")
        self.weaponStrength.grid(sticky= W, row=5, column=2)

        self.weaponStrengthLabel = Label(self.PlayerFrame, text="Weapon Strength:")
        self.weaponStrengthLabel.grid(sticky= E, row=5, column=1)

        self.playerFood = Label(self.PlayerFrame, text="0")
        self.playerFood.grid(sticky=W, row=6, column=2)

        self.playerFoodLabel = Label(self.PlayerFrame, text="Player food:")
        self.playerFoodLabel.grid(sticky=E, row=6, column=1)

        self.food = Button(self.PlayerFrame, text="Eat food to restore 10 health", command = self.eatFood)
        self.food.grid(row=7,column = 1, padx=2, pady=2)

        ###WIDGETS TO GO IN MONSTER FRAME ###
        self.monster.set("Choose your opponent") # default value

        self.monsterMenu = OptionMenu(self.MonsterFrame, self.monster, "Abyssal Demon", "Gargoyle", "Greater Demon","Hill Giant", command = self.monsters)
        self.monsterMenu.grid(row=2, column= 0, sticky=E)

        self.monsterHealthLabel = Label(self.MonsterFrame, text="Opponent health:")
        self.monsterHealthLabel.grid(row=3, column=0, sticky=E)

        self.monsterHealth = Label(self.MonsterFrame, text="0")
        self.monsterHealth.grid(row=3, column=1, sticky=W)

        self.monsterStrengthLabel = Label(self.MonsterFrame, text="Opponent strength:")
        self.monsterStrengthLabel.grid(row=4, column=0, sticky=E)

        self.monsterStrength = Label(self.MonsterFrame, text="0")
        self.monsterStrength.grid(row=4, column=1, sticky=W)

        ### WIDGETS TO GO IN FIGHT FRAME ###
        self.startFight=Button(self.FightFrame, text="Fight!", command = self.fight)
        self.startFight.grid(row=3, column=1)

        self.oppDamageLabel=Label(self.FightFrame, text="Damage to opponent")
        self.oppDamageLabel.grid(row=0, column=2)
        self.opponentDamage = Label(self.FightFrame, text="", font=("",30), fg="red")
        self.opponentDamage.grid(row=2, column=2)

        self.playerDamageLabel=Label(self.FightFrame, text="Damage to player")
        self.playerDamageLabel.grid(row=0, column=0)
        self.playerDamage = Label(self.FightFrame, text="", font=("",30), fg="red")
        self.playerDamage.grid(row=2, column=0)

def main():
    DragonSlayer().mainloop()

main()
